Mod shuld be installed automaticly through steam workshop 
Link: https://steamcommunity.com/sharedfiles/filedetails/?id=2491037405&searchtext=accordion

Part of code are borrowed from "Кебаб аккордеон" Barotrauma mod that can be found here: https://steamcommunity.com/sharedfiles/filedetails/?id=1928545074&searchtext=accordion